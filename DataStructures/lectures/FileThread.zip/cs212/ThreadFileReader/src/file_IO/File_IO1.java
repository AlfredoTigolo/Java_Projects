package file_IO;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

//package thread;
import java.io.*;
import java.util.*;

public class File_IO1 {
  public static void main(String[] args) throws IOException{
String file = null, line;
file = "Customers.csv";
BufferedReader buf = null;
BufferedReader answer = new BufferedReader(new InputStreamReader(System.in));
BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
int lineNum = 0;
char ans = 'y';

while(ans == 'y'){
  buf = new BufferedReader(new FileReader(file));
  line = buf.readLine();

  while(line != null){
    lineNum++;
    System.out.println(line);
    line = buf.readLine();
  }//end of WHILE()

System.out.println("Enter <n/N> to quit, else press any key: ");
  String input = answer.readLine();
  if(input.length() == 0)  //If the user presses the <ENTER> key.
    ans = 'y';  //Assume that the user'd like to continue, so the answer is 'y'.
  else
    ans = input.charAt(0);
  }  //END of WHILE
}//end of main()
}//end of class File_IO1{}
