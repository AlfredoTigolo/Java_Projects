package thread2;

public class Account {
  private int balance;
  private int accountNumber;
  //Constructor
  public Account(int accountNumber, int balance){
    this.accountNumber = accountNumber;
    this.balance = balance;
  }
  //Return the current balance
  public int getBalance(){return balance;}
  //Set the current balance
  public void setBalance(int balance){this.balance = balance;}
  public int getAccountNumber(){return accountNumber;}
  public String toString(){
    return ("Account #: " + accountNumber + " : $" + balance);
  }
}//end of class Account{}