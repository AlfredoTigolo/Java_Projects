package thread2;

public class Bank {
//Perform a transaction
  public void doTransaction(Transaction transaction){
    int balance = transaction.getAccount().getBalance();  //get current balance

    switch(transaction.getTransactionType()){
      case Transaction.CREDIT :
        try{ Thread.sleep(100);}
        catch(InterruptedException e){ System.out.println(e);}

        balance += transaction.getAmount();
        break;
      case Transaction.DEBIT :
        try{ Thread.sleep(150);}
        catch(InterruptedException e){ System.out.println(e);}

        balance -= transaction.getAmount();
        break;
      default:
        System.out.println("Invalid transaction");
      System.exit(1);
    }//end of switch()
    transaction.getAccount().setBalance(balance);
  }//end of Transaction()
}//end of class Bank{}