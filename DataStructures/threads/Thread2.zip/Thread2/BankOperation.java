package thread2;
import java.util.Random;

public class BankOperation {
  public static void main(String[] args) {
    int initialBalance = 500;
    int totalCredits = 0;
    int totalDebits = 0;
    int transactionCount = 20;  //numbers of debits and credits
//Create the account, bank and the clerk
  Bank theBank = new Bank();
  Clerk clerk1 = new Clerk(theBank);
  Clerk clerk2 = new Clerk(theBank);
  Account account = new Account(1, initialBalance);
//Create the threads for the clerks as daemon, and start them off
  Thread clerk1Thread = new Thread(clerk1);
  Thread clerk2Thread = new Thread(clerk2);
  clerk1Thread.setDaemon(true);
  clerk2Thread.setDaemon(true);
    clerk1Thread.start();
    clerk2Thread.start();
//Generate transactions of each type and pass to the clerk
  Random rand = new Random();
  Transaction transaction;
  int amount;
  for(int i = 1; i <= transactionCount; i++){
    amount = 50 + rand.nextInt(26); //Generate amount of $50-$75
    transaction = new Transaction(account, Transaction.CREDIT, amount);
    totalCredits += amount;  //keep total credits tally
//Wait until the first clerk is free.
  while(clerk1.isBusy())
    try{ Thread.sleep(25);}  //busy so try it later.
    catch(InterruptedException e){ System.out.println(e);}
    clerk1.doTransaction(transaction);

    amount = 30 + rand.nextInt(31);//generate amount of $30 to $60
    transaction = new Transaction(account, Transaction.DEBIT, amount);
    totalDebits += amount;  //keep total debits tally
//Wait unitl the second clerk is free
  while(clerk2.isBusy())
    try{ Thread.sleep(25);}
    catch(InterruptedException e){ System.out.println(e);}
    clerk2.doTransaction(transaction);
  }//end of FOR{}
//Wait until both clerks are done
  while(clerk1.isBusy())
    try{  Thread.sleep(25);}
    catch(InterruptedException e){ System.out.println(e);}
//Now output the result
  System.out.println(
        "Original balance   : $" + initialBalance + "\n" +
        "Total credits      : $" + totalCredits + "\n" +
        "TotalDebits        : $" + totalDebits + "\n" +
        "Final balance      : $" + account.getBalance() + "\n" +
        "should be          : $" + (initialBalance + totalCredits - totalDebits));
  }//end of main()
}//end of calss BankOperation{}